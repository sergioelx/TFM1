package org.cmd;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.ontoenrich.tfm.OWLOntologyReuseMetric;
import org.ontoenrich.tfm.OWLOntologyReuse_JSONOuput;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RunExperiment {

	public static void main(String[] args) throws MalformedURLException, IOException {

		Map<String, URL> oboFoundryCorpus = getOBOFoundryCorpus();
		
		for ( String ontologyId : oboFoundryCorpus.keySet() ) {
			if ( ontologyId.compareTo("to") == 0 ) {
				long inicio = System.currentTimeMillis();
	       
				try {
					// STEP 1: create the IRI of the ontology
					IRI ontologyIri = IRI.create(oboFoundryCorpus.get(ontologyId));
			
					DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
					Date date = new Date();
					System.out.println("Hora actual: " + dateFormat.format(date));
	        		System.out.println();
	        	
	        		// STEP 2: load the ontology
	        		final OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
	        		System.out.println("Loading ontology "+ontologyId+"...");

	        		if ( ontologyIri != null  ) {
	        			final OWLOntology owlOntology = manager.loadOntologyFromOntologyDocument(ontologyIri);
				
	        			// STEP 3: create the object and calculate de REUSE metric
	        			OWLOntologyReuseMetric reuseMetric = new OWLOntologyReuseMetric(owlOntology);
	        			OWLOntologyReuse_JSONOuput jsonResultObject = reuseMetric.calculateMetric();
	        			System.out.println(jsonResultObject);
	        			
	        			// PRINT JSON
	        			File tmpFile = File.createTempFile("tmp", ".json");
	        			ObjectMapper mapper = new ObjectMapper();
	        			mapper.writeValue(tmpFile, jsonResultObject);
	        			String jsonInString = mapper.writeValueAsString(jsonResultObject);
	        			System.out.println(jsonInString);
	        			System.out.println(tmpFile.getPath());
	        			
	        		}
	        		else {
	        			System.out.println("Warning: no IRI found.");
	        		}
				}
				catch (Exception e) {
					System.out.println("ERROR: excepcion capturada. Mensaje: "+e.getMessage());
				}
			
				long fin = System.currentTimeMillis();
	        	double tiempo = (double) ((fin - inicio)/1000);
	        	System.out.println(tiempo +" segundos");
	        	System.out.println();
			}	
		}
	}
	
	private static Map<String, URL> getOBOFoundryCorpus() throws MalformedURLException, IOException {
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode json = mapper.readTree(new URL("https://obofoundry.org/registry/ontologies.jsonld"));
	    Iterator<JsonNode> itOntologies = json.get("ontologies").iterator();
	    Map<String, URL> result = new HashMap<String, URL>();
	    while (itOntologies.hasNext() ) {
	    	JsonNode ontology = itOntologies.next();
	    	JsonNode ontologyId = ontology.get("id");
	    	JsonNode ontologyPurl = ontology.get("ontology_purl");
	    	if ( ontologyPurl != null  ) {
	    		result.put(ontologyId.textValue(), new URL(ontologyPurl.textValue()));
	    	}
	    	else {
	    		result.put(ontologyId.textValue(), null);
	    	}
	    }
	    return result;
	}
	
}
