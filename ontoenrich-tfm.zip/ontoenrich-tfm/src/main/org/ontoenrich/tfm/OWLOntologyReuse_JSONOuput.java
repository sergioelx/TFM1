package org.ontoenrich.tfm;

import java.util.List;

public class OWLOntologyReuse_JSONOuput {

	private Manuel objManuel = new Manuel(); 
	private String idOntology;
	private List<String> imports;
	
	public OWLOntologyReuse_JSONOuput (String idOntology, List<String> imports) {
		this.idOntology = idOntology;
		this.imports = imports;
	}
	
	// GETTERS
	
	public Manuel getObjManuel() {
		return objManuel;
	}
	
	public String getIdOntology() {
		return idOntology;
	}
	
	public List<String> getImports() {
		return imports;
	}
		
}

class Manuel {
	private String nombre = "Mnuel";
	private String apellido = "Quesada";
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellido() {
		return apellido;
	}
}
