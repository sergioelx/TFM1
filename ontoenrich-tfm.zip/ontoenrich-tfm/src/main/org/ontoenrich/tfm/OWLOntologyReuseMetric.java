package org.ontoenrich.tfm;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLOntology;

public class OWLOntologyReuseMetric {
	
	private OWLOntology owlOntology = null;
	
	public OWLOntologyReuseMetric (OWLOntology owlOntology ) {
		this.owlOntology = owlOntology;
	}

	public OWLOntologyReuse_JSONOuput calculateMetric() {

		OWLOntologyReuse_JSONOuput resultMetric = new OWLOntologyReuse_JSONOuput(
				owlOntology.getOntologyID().getOntologyIRI().toString(), 
				new ArrayList<String>());
		
		//System.out.println(owlOntology.getOntologyID().getOntologyIRI()+" - "+owlOntology.getClassesInSignature().size());
		
		// IMPORTS
		//System.out.println("IMPORTS:");
		ArrayList<OWLOntology> imports = new ArrayList<OWLOntology>();
		owlOntology.imports().forEach(imports::add);
		if ( imports.isEmpty() ) {
			//System.out.println("None");
		}
		for ( OWLOntology importedOntology : imports ) {
			//System.out.println(importedOntology.getOntologyID().getOntologyIRI()+" - "+importedOntology.getClassesInSignature().size());
			resultMetric.getImports().add(importedOntology.getOntologyID().getOntologyIRI().toString());
		}
		System.out.println();
		
		// IMPORTS CLOSURE
		/*System.out.println("IMPORTS CLOSURE:");
		ArrayList<OWLOntology> importsClosure = new ArrayList<OWLOntology>();
		owlOntology.importsClosure().forEach(importsClosure::add);
		if ( importsClosure.isEmpty() ) {
			System.out.println("None");
		}
		for ( OWLOntology importedOntology : importsClosure ) {
			System.out.println(importedOntology.getOntologyID().getOntologyIRI()+" - "+importedOntology.getClassesInSignature().size());
		}
		System.out.println();
		
		// IMPORTS DECLARATIONS
		System.out.println("Imports DECLARATIONS:");
		ArrayList<OWLImportsDeclaration> importDeclarations = new ArrayList<OWLImportsDeclaration>();
		owlOntology.importsDeclarations().forEach(importDeclarations::add);
		if ( importDeclarations.isEmpty() ) {
			System.out.println("None");
		}
		for ( OWLImportsDeclaration owlImportsDeclaration : importDeclarations ) {
			System.out.println(owlImportsDeclaration);
		}
		
		System.out.println();
		System.out.println("-----------------------------------");
		System.out.println();*/
		
		return resultMetric;
	}
	
}
