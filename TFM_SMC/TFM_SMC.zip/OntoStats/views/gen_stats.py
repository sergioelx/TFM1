from flask import render_template, Blueprint, send_file, redirect, url_for, request
import os
import plotly.graph_objs as go
import json
import networkx as nx
from urllib.parse import urlparse


gen = Blueprint('gen', __name__)



@gen.route('/gen_stats', methods=('GET', 'POST'))
def gen_stats():

    #graph_json = generate_graph()
    with open('output.json') as f:
        data = json.load(f)
    # Crear el gráfico
    fig = create_ontology_graph(data)
    # Convertir el gráfico a HTML
    graph_html = fig.to_html(full_html=False)

    ontology_title = data.get('ontologyTitle', None)

    metrics = ['axiomCount', 'declarationAxiomCount', 'classCount', 'objectPropertyCount', 'dataPropertyCount', 'individualCount', 'annotationPropertyCount', 'weight']
    graph_html2 = {}
    for metric in metrics:
        graph_html2[metric] = create_bar_chart(data, metric)


    # Envía el archivo al cliente para descargarlo
    return render_template("gen_stats.html",graph_html=graph_html, graph_html2=graph_html2, ontology_title = ontology_title)


@gen.route('/download_json', methods=['GET'])
def download_json():
    # Obtener la ruta absoluta del archivo JSON
    root_dir = os.path.abspath(os.path.join(os.getcwd(), os.path.dirname(__file__), "..", ".."))
    json_filename = 'output.json'
    json_url = os.path.join(root_dir, json_filename)


    # Enviar el archivo JSON al cliente para descargarlo
    return send_file(json_url, as_attachment=True)

# Función para obtener la parte final de la URL sin la extensión .owl
def get_final_part(url):
    parsed_url = urlparse(url)
    last_part = parsed_url.path.split('/')[-1]
    return last_part.replace('.owl', '')

# Función para obtener el nombre de la ontología padre
def get_parent_ontology(url):
    parsed_url = urlparse(url)
    parts = parsed_url.path.split('/')
    if 'imports' in parts:
        index = parts.index('imports')
        return parts[index - 1]
    else:
        return None

def create_ontology_graph(data):
    # Crear un grafo dirigido
    G = nx.DiGraph()

    # Agregar la ontología original como nodo central
    original_ontology = data['idOntology']
    original_ontology_name = get_final_part(original_ontology)
    G.add_node(original_ontology_name)

    # Agregar los imports como nodos y conexiones al grafo
    for entry in data['imports']:
        ontology_id = entry['idOntology']
        parent_ontology = get_parent_ontology(ontology_id)
        imported_ontology_name = get_final_part(ontology_id)
        G.add_node(imported_ontology_name)
        G.add_edge(get_final_part(parent_ontology) if parent_ontology else original_ontology_name, imported_ontology_name)
    
    # Obtener el axiom count para cada nodo
    axiom_counts = {get_final_part(entry['idOntology']): entry['ontologyMetrics']['axiomCount'] for entry in data['imports']}
    # Obtener el class count para cada nodo
    class_counts = {get_final_part(entry['idOntology']): entry['ontologyMetrics']['classCount'] for entry in data['imports']}
    # Añadir el axiom count y class count de la ontología original al diccionario
    axiom_counts[original_ontology_name] = data['ontologyMetrics']['axiomCount']
    class_counts[original_ontology_name] = data['ontologyMetrics']['classCount']
    
    # Escalar los tamaños del círculo entre un rango definido (aquí, entre 5 y 30)
    min_axiom_count = min(axiom_counts.values())
    max_axiom_count = max(axiom_counts.values())
    scaled_sizes = {node: 20 + (axiom_counts[node] - min_axiom_count) / (max_axiom_count - min_axiom_count) * 100 for node in axiom_counts}

    # Calcular las posiciones de los nodos para la visualización
    pos = nx.spring_layout(G)

    # Crear los trazos del gráfico
    node_trace = go.Scatter(x=[], y=[], text=[], mode='markers+text', hoverinfo='text', marker=dict(size=[], color='LightSkyBlue'))
    edge_trace = go.Scatter(x=[], y=[], line=dict(width=1, color='#888'))

    # Agregar posiciones de los nodos al trazo de los nodos
    for node in G.nodes():
        x, y = pos[node]
        node_trace['x'] += (x,)
        node_trace['y'] += (y,)
        # Obtener el nombre de la ontología padre
        parent_ontology = get_parent_ontology(data['idOntology'])
        print(parent_ontology)
        # Crear el texto que se mostrará al pasar el ratón sobre el nodo
        if parent_ontology:
            text = f"{parent_ontology}/{node}"

        else:
            text = node

        node_trace['text'] += (text,)
        
        node_trace['marker']['size'] += (scaled_sizes[node],)

    # Agregar posiciones de los bordes al trazo de los bordes
    for edge in G.edges():
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_trace['x'] += (x0, x1, None)
        edge_trace['y'] += (y0, y1, None)

    # Crear el gráfico
    fig = go.Figure(data=[edge_trace, node_trace],
                    layout=go.Layout(
                        title='Ontology Graph',
                        titlefont_size=16,
                        showlegend=False,
                        hovermode='closest',
                        margin=dict(b=20,l=5,r=5,t=40),
                        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
                    )
    return fig

def create_bar_chart(data, metric_name):

    
    ontologies = data['imports']  # Lista de ontologías importadas

    ontology_names = [get_final_part(ontology['idOntology']) for ontology in ontologies]  # Corrección aquí
    parent_ontology_names = [get_parent_ontology(ontology['idOntology']) for ontology in ontologies]
    metric_values = [ontology['ontologyMetrics'][metric_name] for ontology in ontologies]

    # Agregar los datos de la ontología original al principio de las listas
    original_ontology_name = get_final_part(data['idOntology'])
    parent_ontology_name = get_parent_ontology(data['idOntology'])
    original_metric_value = data['ontologyMetrics'][metric_name]

    ontology_names.insert(0, original_ontology_name)
    parent_ontology_names.insert(0, parent_ontology_name)
    metric_values.insert(0, original_metric_value)

    # Asignar colores a las barras
    colors = ['red'] + ['blue' for _ in parent_ontology_names[1:]]

    # Crear el gráfico de barras
    trace = go.Bar(
        x=[f"{parent}|{ontology}" if parent else ontology for ontology, parent in zip(ontology_names, parent_ontology_names)],
        y=metric_values,
        marker=dict(color=colors)  # Asignar colores
    )

    layout = go.Layout(
        title=f'Comparacion de {metric_name}',  # Título del gráfico
        xaxis=dict(title='Ontologies'),  # Etiqueta del eje X
        yaxis=dict(title=metric_name)     # Etiqueta del eje Y
    )

    fig = go.Figure(data=[trace], layout=layout)

    # Convertir el gráfico a HTML
    graph_html = fig.to_html(full_html=False)

    return graph_html

